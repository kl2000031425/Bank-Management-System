package id5.sdp3.service;

public interface UserService 
{
	public void register();

}
