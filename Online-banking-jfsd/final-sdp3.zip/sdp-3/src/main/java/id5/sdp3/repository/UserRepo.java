package id5.sdp3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id5.sdp3.entity.LoginData;

public interface UserRepo extends JpaRepository<LoginData,Integer>
{

}
