package id5.sdp3.service;

import org.springframework.beans.factory.annotation.Autowired;
import id5.sdp3.repository.*;

public class UserSerImp implements UserService
{

	@Override
	public void register() {
		// TODO Auto-generated method stub
		
	}

}
