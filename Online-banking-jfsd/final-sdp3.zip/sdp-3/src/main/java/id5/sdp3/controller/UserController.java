package id5.sdp3.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import id5.sdp3.entity.LoginData;
import id5.sdp3.repository.UserRepo;


@Controller
public class UserController 
{
	@Autowired
	private UserRepo r;
	
	@GetMapping(value="/")
	public String home()
	{
		return "home.html";
	}
	@GetMapping(value="/login.html")
	public String login()
	{
		return "login.html";
	}
	@GetMapping(value="/register.html")
	public String register()
	{
		
		return "register.html";
	}
	@GetMapping(value="/land.jsp")
	public String land()
	{
		return "land.jsp";
	}
	@PostMapping(value="/login.jsp")
	public String register(@ModelAttribute LoginData l,HttpSession session)
	{
		r.save(l);
		session.setAttribute("message", "registered sucessfully");
		return "redirect:/login.jsp";
	}
}
